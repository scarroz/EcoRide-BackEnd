package co.edu.unbosque.tripservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
