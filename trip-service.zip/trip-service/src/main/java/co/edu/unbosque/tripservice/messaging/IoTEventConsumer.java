
package co.edu.unbosque.tripservice.messaging;

import co.edu.unbosque.tripservice.dto.BikeIoTDataDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class IoTEventConsumer {

    private final ObjectMapper objectMapper;

    public IoTEventConsumer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @KafkaListener(topics = "bicycle-telemetry", groupId = "trip-service-group")
    public void consumeTelemetry(String message) {
        try {
            BikeIoTDataDTO telemetry = objectMapper.readValue(message, BikeIoTDataDTO.class);

            System.out.println("Telemetria recibida - Bike: " + telemetry.bikeId() +
                    " Pos: " + telemetry.lat() + "," + telemetry.lon());

            // Procesar telemetria: guardar en BD, validar posicion, etc.
            processTelemetry(telemetry);

        } catch (Exception e) {
            System.err.println("Error procesando telemetria: " + e.getMessage());
        }
    }

    @KafkaListener(topics = "bicycle-lock-status", groupId = "trip-service-group")
    public void consumeLockStatus(String message) {
        try {
            System.out.println("Lock status recibido: " + message);
            // Procesar cambios de estado de candado

        } catch (Exception e) {
            System.err.println("Error procesando lock status: " + e.getMessage());
        }
    }

    @KafkaListener(topics = "bicycle-battery", groupId = "trip-service-group")
    public void consumeBatteryStatus(String message) {
        try {
            System.out.println("Battery status recibido: " + message);
            // Procesar cambios de bateria, alertar si esta baja

        } catch (Exception e) {
            System.err.println("Error procesando battery status: " + e.getMessage());
        }
    }

    private void processTelemetry(BikeIoTDataDTO telemetry) {
        // Validar que la bicicleta esta en movimiento dentro de limites permitidos
        // Detectar posibles abandonos (fuera de estaciones por >80 min)
        // Actualizar metricas de viaje
    }
}