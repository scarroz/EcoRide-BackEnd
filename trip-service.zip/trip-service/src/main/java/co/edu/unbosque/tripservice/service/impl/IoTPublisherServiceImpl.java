package co.edu.unbosque.tripservice.service.impl;


import co.edu.unbosque.tripservice.dto.BikeIoTDataDTO;
import co.edu.unbosque.tripservice.dto.LockStatusDTO;
import co.edu.unbosque.tripservice.service.IoTPublisherService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class IoTPublisherServiceImpl implements IoTPublisherService {

    private static final String TOPIC_TELEMETRY = "bicycle-telemetry";
    private static final String TOPIC_LOCK_STATUS = "bicycle-lock-status";
    private static final String TOPIC_BATTERY = "bicycle-battery";

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    // Almacena viajes activos para telemetria
    private final Map<Long, TripTelemetryData> activeTrips = new ConcurrentHashMap<>();

    public IoTPublisherServiceImpl(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }



    /**
     * Publica cambio de estado del candado
     */
    public void publishLockStatus(Long bicycleId, String status) {
        try {
            LockStatusDTO lockStatus = new LockStatusDTO(
                    bicycleId,
                    status,
                    LocalDateTime.now()
            );

            String message = objectMapper.writeValueAsString(lockStatus);
            kafkaTemplate.send(TOPIC_LOCK_STATUS, bicycleId.toString(), message);

            System.out.println("Evento IoT publicado - Lock Status: " + bicycleId + " -> " + status);

        } catch (JsonProcessingException e) {
            System.err.println("Error serializando mensaje IoT: " + e.getMessage());
        }
    }

    /**
     * Inicia telemetria de viaje activo
     */
    public void startTripTelemetry(Long tripId, Long bicycleId) {
        TripTelemetryData telemetry = new TripTelemetryData(
                tripId,
                bicycleId,
                LocalDateTime.now()
        );

        activeTrips.put(tripId, telemetry);
        System.out.println("Telemetria iniciada para viaje: " + tripId);
    }

    /**
     * Detiene telemetria de viaje
     */
    public void stopTripTelemetry(Long tripId) {
        activeTrips.remove(tripId);
        System.out.println("Telemetria detenida para viaje: " + tripId);
    }

    /**
     * Tarea programada para enviar telemetria cada 20 segundos
     */
    @Scheduled(fixedRate = 20000) // 20 segundos
    @Async
    public void publishActiveTripsTelemetry() {
        if (activeTrips.isEmpty()) {
            return;
        }

        System.out.println("Publicando telemetria de " + activeTrips.size() + " viajes activos");

        activeTrips.values().forEach(telemetry -> {
            try {
                BikeIoTDataDTO iotData = generateTelemetryData(telemetry);
                String message = objectMapper.writeValueAsString(iotData);

                kafkaTemplate.send(TOPIC_TELEMETRY, telemetry.bicycleId.toString(), message);

            } catch (JsonProcessingException e) {
                System.err.println("Error publicando telemetria: " + e.getMessage());
            }
        });
    }

    /**
     * Publica estado de bateria de bicicletas electricas
     */
    public void publishBatteryStatus(Long bicycleId, Integer batteryLevel) {
        try {
            Map<String, Object> batteryData = Map.of(
                    "bikeId", bicycleId,
                    "battery", batteryLevel,
                    "timestamp", LocalDateTime.now().toString()
            );

            String message = objectMapper.writeValueAsString(batteryData);
            kafkaTemplate.send(TOPIC_BATTERY, bicycleId.toString(), message);

            System.out.println("Bateria publicada - Bike: " + bicycleId + " -> " + batteryLevel + "%");

        } catch (JsonProcessingException e) {
            System.err.println("Error publicando bateria: " + e.getMessage());
        }
    }

    /**
     * Genera datos de telemetria simulados para el viaje activo
     */
    private BikeIoTDataDTO generateTelemetryData(TripTelemetryData telemetry) {
        // Simular posicion GPS en movimiento dentro de Bogota
        BigDecimal baseLat = new BigDecimal("4.6500");
        BigDecimal baseLon = new BigDecimal("-74.0800");

        // Agregar variacion aleatoria para simular movimiento
        BigDecimal latVariation = BigDecimal.valueOf(Math.random() * 0.01 - 0.005);
        BigDecimal lonVariation = BigDecimal.valueOf(Math.random() * 0.01 - 0.005);

        BigDecimal currentLat = baseLat.add(latVariation);
        BigDecimal currentLon = baseLon.add(lonVariation);

        // Simular nivel de bateria (solo para electricas)
        Integer battery = (int) (100 - Math.random() * 20);

        return new BikeIoTDataDTO(
                telemetry.bicycleId,
                LocalDateTime.now().toString(),
                currentLat,
                currentLon,
                battery,
                "UNLOCKED"
        );
    }

    /**
     * Clase interna para almacenar datos de telemetria activa
     */
    private static class TripTelemetryData {
        Long tripId;
        Long bicycleId;
        LocalDateTime startTime;

        public TripTelemetryData(Long tripId, Long bicycleId, LocalDateTime startTime) {
            this.tripId = tripId;
            this.bicycleId = bicycleId;
            this.startTime = startTime;
        }
    }
}
