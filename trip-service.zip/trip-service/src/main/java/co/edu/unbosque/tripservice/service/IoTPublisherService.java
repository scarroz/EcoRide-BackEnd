package co.edu.unbosque.tripservice.service;


public interface IoTPublisherService {

    /**
     * Publica un evento de cambio de estado del candado (bloqueado/desbloqueado).
     *
     * @param bicycleId ID de la bicicleta
     * @param status    Estado del candado ("LOCKED" o "UNLOCKED")
     */
    void publishLockStatus(Long bicycleId, String status);

    /**
     * Inicia el envío periódico de telemetría para un viaje activo.
     *
     * @param tripId    ID del viaje
     * @param bicycleId ID de la bicicleta
     */
    void startTripTelemetry(Long tripId, Long bicycleId);

    /**
     * Detiene el envío de telemetría para un viaje activo.
     *
     * @param tripId ID del viaje
     */
    void stopTripTelemetry(Long tripId);

    /**
     * Publica el estado de batería de una bicicleta eléctrica.
     *
     * @param bicycleId    ID de la bicicleta
     * @param batteryLevel Nivel de batería en porcentaje (0–100)
     */
    void publishBatteryStatus(Long bicycleId, Integer batteryLevel);
}

