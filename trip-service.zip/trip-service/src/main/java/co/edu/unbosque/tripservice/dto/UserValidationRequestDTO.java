package co.edu.unbosque.tripservice.dto;

public record UserValidationRequestDTO(
        Long userId
) {}
