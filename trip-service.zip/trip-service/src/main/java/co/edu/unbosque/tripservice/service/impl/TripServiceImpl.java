package co.edu.unbosque.tripservice.service.impl;

import co.edu.unbosque.tripservice.client.*;
import co.edu.unbosque.tripservice.dto.*;
import co.edu.unbosque.tripservice.mapper.DataMapper;
import co.edu.unbosque.tripservice.model.*;
import co.edu.unbosque.tripservice.repository.*;
import co.edu.unbosque.tripservice.service.IoTPublisherService;
import co.edu.unbosque.tripservice.service.RouteValidationService;
import co.edu.unbosque.tripservice.service.TripService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TripServiceImpl implements TripService {

    private final TripRepository tripRepo;
    private final BicycleRepository bicycleRepo;
    private final StationRepository stationRepo;
    private final ReservationRepository reservationRepo;
    private final DataMapper mapper;
    private final UserServiceClient userClient;
    private final PaymentServiceClient paymentClient;
    private final IoTPublisherService iotPublisher;
    private final RouteValidationService routeValidation;

    // Constantes de costos
    private static final BigDecimal LAST_MILE_BASE_COST = new BigDecimal("17500");
    private static final BigDecimal LAST_MILE_EXTRA_MINUTE = new BigDecimal("250");
    private static final int LAST_MILE_MAX_MINUTES = 45;

    private static final BigDecimal LONG_DISTANCE_BASE_COST = new BigDecimal("25000");
    private static final BigDecimal LONG_DISTANCE_EXTRA_MINUTE = new BigDecimal("1000");
    private static final int LONG_DISTANCE_MAX_MINUTES = 75;

    public TripServiceImpl(
            TripRepository tripRepo,
            BicycleRepository bicycleRepo,
            StationRepository stationRepo,
            ReservationRepository reservationRepo,
            DataMapper mapper,
            UserServiceClient userClient,
            PaymentServiceClient paymentClient,
            IoTPublisherService iotPublisher,
            RouteValidationService routeValidation
    ) {
        this.tripRepo = tripRepo;
        this.bicycleRepo = bicycleRepo;
        this.stationRepo = stationRepo;
        this.reservationRepo = reservationRepo;
        this.mapper = mapper;
        this.userClient = userClient;
        this.paymentClient = paymentClient;
        this.iotPublisher = iotPublisher;
        this.routeValidation = routeValidation;
    }

    @Override
    @Transactional
    public TripResponseDTO startTrip(TripStartRequestDTO request) {
        System.out.println("Iniciando viaje para usuario: " + request.userId());

        // 1. Validar usuario
        UserValidationResponseDTO userValidation = userClient.validateUser(request.userId());
        if (!userValidation.valid()) {
            throw new RuntimeException("Usuario invalido o con saldo insuficiente");
        }

        // 2. Verificar que no tenga viajes activos
        tripRepo.findByUserIdAndStatus(request.userId(), "IN_PROGRESS")
                .ifPresent(t -> {
                    throw new RuntimeException("Usuario ya tiene un viaje activo");
                });

        // 3. Obtener bicicleta
        Bicycle bicycle = bicycleRepo.findById(request.bicycleId())
                .orElseThrow(() -> new RuntimeException("Bicicleta no encontrada"));

        // 4. Validar disponibilidad de bicicleta
        validateBicycleAvailability(bicycle);

        // 5. Obtener estacion de inicio
        Station startStation = stationRepo.findById(request.stationId())
                .orElseThrow(() -> new RuntimeException("Estacion no encontrada"));

        // 6. Verificar reserva activa si existe
        reservationRepo.findByUserIdAndStatus(request.userId(), "ACTIVE")
                .ifPresent(reservation -> {
                    if (!reservation.getBicycle().getId().equals(bicycle.getId())) {
                        throw new RuntimeException("La bicicleta no coincide con la reserva");
                    }
                    reservation.setStatus("USED");
                    reservationRepo.save(reservation);
                });

        // 7. Validar tipo de viaje
        validateTripType(request.tripType(), startStation);

        // 8. Crear viaje
        Trip trip = mapper.toTripEntity(
                request.userId(),
                bicycle,
                startStation,
                request.tripType(),
                request.paymentSource()
        );

        // 9. Actualizar estado de bicicleta
        bicycle.setStatus("IN_USE");
        bicycleRepo.save(bicycle);

        // 10. Guardar viaje
        trip = tripRepo.save(trip);

        System.out.println("Viaje creado con ID: " + trip.getId());

        // 11. Publicar evento IoT de desbloqueo
        iotPublisher.publishLockStatus(bicycle.getId(), "UNLOCKED");

        // 12. Iniciar telemetria
        iotPublisher.startTripTelemetry(trip.getId(), bicycle.getId());

        // 13. Notificar a usuario
        userClient.notifyTripStarted(request.userId(), trip.getId());

        return mapper.toTripResponseDTO(trip);
    }

    @Override
    @Transactional
    public TripResponseDTO endTrip(TripEndRequestDTO request) {
        System.out.println("Finalizando viaje: " + request.tripId());

        // 1. Obtener viaje
        Trip trip = tripRepo.findById(request.tripId())
                .orElseThrow(() -> new RuntimeException("Viaje no encontrado"));

        if (!"IN_PROGRESS".equals(trip.getStatus())) {
            throw new RuntimeException("El viaje no esta activo");
        }

        // 2. Obtener estacion de finalizacion
        Station endStation = stationRepo.findById(request.endStationId())
                .orElseThrow(() -> new RuntimeException("Estacion de destino no encontrada"));

        // 3. Validar capacidad de estacion
        Integer availableSlots = endStation.getCapacity() -
                bicycleRepo.countAvailableBicyclesByStation(endStation.getId());

        if (availableSlots <= 0) {
            throw new RuntimeException("La estacion destino esta llena");
        }

        // 4. Validar posicion GPS
        RouteValidationResponseDTO routeValidation = this.routeValidation.validateFinalPosition(
                endStation.getLatitude(),
                endStation.getLongitude(),
                request.finalLatitude(),
                request.finalLongitude()
        );

        if (!routeValidation.valid()) {
            throw new RuntimeException("La posicion GPS no coincide con la estacion");
        }

        // 5. Calcular duracion y costo
        trip.setEndTime(LocalDateTime.now());
        trip.setEndStation(endStation);

        long durationMinutes = Duration.between(trip.getStartTime(), trip.getEndTime()).toMinutes();
        BigDecimal totalCost = calculateTripCost(trip.getTripType(), durationMinutes);

        trip.setTotalCost(totalCost);
        trip.setDistanceKm(routeValidation.distanceKm());

        // 6. Actualizar estado de bicicleta
        Bicycle bicycle = trip.getBicycle();
        bicycle.setStatus("AVAILABLE");
        bicycle.setLastStation(endStation);
        bicycleRepo.save(bicycle);

        // 7. Publicar evento IoT de bloqueo
        iotPublisher.publishLockStatus(bicycle.getId(), "LOCKED");

        // 8. Detener telemetria
        iotPublisher.stopTripTelemetry(trip.getId());

        // 9. Procesar pago
        TripPaymentRequestDTO paymentRequest = new TripPaymentRequestDTO(
                trip.getUserId(),
                trip.getId(),
                totalCost,
                trip.getPaymentSource()
        );

        TripPaymentResponseDTO paymentResponse = paymentClient.processTripPayment(paymentRequest);

        if (!"COMPLETED".equals(paymentResponse.status())) {
            trip.setStatus("PAYMENT_FAILED");
            tripRepo.save(trip);
            throw new RuntimeException("Error al procesar el pago del viaje");
        }

        // 10. Actualizar estado del viaje
        trip.setStatus("COMPLETED");
        trip = tripRepo.save(trip);

        System.out.println("Viaje finalizado exitosamente. Costo: " + totalCost);

        // 11. Notificar finalizacion
        userClient.notifyTripCompleted(trip.getUserId(), trip.getId(), totalCost);

        return mapper.toTripResponseDTO(trip);
    }

    @Override
    public List<TripResponseDTO> getUserTrips(Long userId) {
        return tripRepo.findByUserIdOrderByStartTimeDesc(userId)
                .stream()
                .map(mapper::toTripResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public TripDetailDTO getTripDetail(Long tripId) {
        Trip trip = tripRepo.findById(tripId)
                .orElseThrow(() -> new RuntimeException("Viaje no encontrado"));

        return mapper.toTripDetailDTO(trip, "User Name"); // Obtener nombre desde UserService
    }

    @Override
    public List<TripResponseDTO> getActiveTrips() {
        return tripRepo.findByStatus("IN_PROGRESS")
                .stream()
                .map(mapper::toTripResponseDTO)
                .collect(Collectors.toList());
    }

    // Metodos privados auxiliares

    private void validateBicycleAvailability(Bicycle bicycle) {
        if (!"AVAILABLE".equals(bicycle.getStatus()) && !"RESERVED".equals(bicycle.getStatus())) {
            throw new RuntimeException("La bicicleta no esta disponible");
        }

        if ("ELECTRIC".equals(bicycle.getType())) {
            if (bicycle.getBatteryLevel() == null || bicycle.getBatteryLevel() < 40) {
                throw new RuntimeException("La bicicleta electrica tiene bateria baja");
            }
        }
    }

    private void validateTripType(String tripType, Station startStation) {
        if (!"LAST_MILE".equals(tripType) && !"LONG_DISTANCE".equals(tripType)) {
            throw new RuntimeException("Tipo de viaje invalido");
        }

        if ("LAST_MILE".equals(tripType)) {
            if (!startStation.getName().contains("Metro")) {
                throw new RuntimeException("Los viajes de ultima milla deben iniciar en estaciones Metro");
            }
        }
    }

    private BigDecimal calculateTripCost(String tripType, long durationMinutes) {
        BigDecimal baseCost;
        BigDecimal extraMinuteCost;
        int maxMinutes;

        if ("LAST_MILE".equals(tripType)) {
            baseCost = LAST_MILE_BASE_COST;
            extraMinuteCost = LAST_MILE_EXTRA_MINUTE;
            maxMinutes = LAST_MILE_MAX_MINUTES;
        } else {
            baseCost = LONG_DISTANCE_BASE_COST;
            extraMinuteCost = LONG_DISTANCE_EXTRA_MINUTE;
            maxMinutes = LONG_DISTANCE_MAX_MINUTES;
        }

        if (durationMinutes <= maxMinutes) {
            return baseCost;
        }

        long extraMinutes = durationMinutes - maxMinutes;
        BigDecimal extraCost = extraMinuteCost.multiply(BigDecimal.valueOf(extraMinutes));

        return baseCost.add(extraCost);
    }
}